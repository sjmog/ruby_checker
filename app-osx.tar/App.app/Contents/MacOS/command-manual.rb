Shoes.show_manual
